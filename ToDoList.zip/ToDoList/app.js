//modules for the program
const express = require("express");
const bodyParser = require("body-parser");
const date = require(__dirname + "/date.js");



//initializing var for express()
const app = express();

//initial array
const items = ["Study","Cook","Sleep"];
const workItems = []; 


//as ejs requires a folder named views (ejs special file format (for html combining it with js vars))
app.set("view engine", "ejs");

//for handling post req
app.use(bodyParser.urlencoded({extended:true}));
//every static files in express should be in a special folder
app.use(express.static("public"));

app.get("/", function(req,res){
  
  let day = date.getDate();

  res.render("list", {listTitle: day, newListItems: items});

});


app.post("/", function (req,res){

  let item = req.body.newItem;
  //url === localhost/work then render something else
  if(req.body.list === "Work"){
    workItems.push(item);
    res.redirect("/work")
  }else{
    items.push(item);
  }
  res.redirect("/"); 

});

//same as home todoList
app.get("/work",function (req,res){
  res.render("list", {listTitle: "Work", newListItems: workItems});
});

app.get("/about",(req,res)=>{
  res.render("about");
});

app.listen(3000, () => {
  console.log("Server started on port 3000");
});